﻿namespace UdemyRestaurantProject.Controllers
{
    internal class AuthorizedAttribute : Attribute
    {
    }
}