using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace UdemyRestaurantProject.Pages.Admin.MenuItems
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
